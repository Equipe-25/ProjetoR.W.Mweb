
namespace RWM_WEB___Project
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.button_cadastro = new System.Windows.Forms.Button();
            this.button_login = new System.Windows.Forms.Button();
            this.textBox_rwm = new System.Windows.Forms.TextBox();
            this.pictureBox1_livro1 = new System.Windows.Forms.PictureBox();
            this.pictureBox3_livro2 = new System.Windows.Forms.PictureBox();
            this.pictureBox4_livro3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4_livro4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5_livro5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6_livro6 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.text_box_rodapeInicial = new System.Windows.Forms.TextBox();
            this.pictureBox7_livro7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8_livro8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9_livro9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10_livro10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11_livro11 = new System.Windows.Forms.PictureBox();
            this.textBox1_telaInicial = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.pictureBox12_livro12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13_background_barra_inicial = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_livro1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_livro2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_livro3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_livro4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_livro5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_livro6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_livro7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8_livro8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9_livro9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10_livro10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11_livro11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12_livro12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13_background_barra_inicial)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(22, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(845, 73);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // button_cadastro
            // 
            this.button_cadastro.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.button_cadastro.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_cadastro.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_cadastro.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.button_cadastro.ForeColor = System.Drawing.SystemColors.Window;
            this.button_cadastro.Location = new System.Drawing.Point(672, 13);
            this.button_cadastro.Name = "button_cadastro";
            this.button_cadastro.Size = new System.Drawing.Size(97, 35);
            this.button_cadastro.TabIndex = 1;
            this.button_cadastro.Text = "Cadastre-se";
            this.button_cadastro.UseVisualStyleBackColor = false;
            this.button_cadastro.Click += new System.EventHandler(this.button1_Click);
            // 
            // button_login
            // 
            this.button_login.BackColor = System.Drawing.Color.MediumSlateBlue;
            this.button_login.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button_login.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button_login.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold);
            this.button_login.ForeColor = System.Drawing.Color.White;
            this.button_login.Location = new System.Drawing.Point(786, 13);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(56, 35);
            this.button_login.TabIndex = 2;
            this.button_login.Text = "Login";
            this.button_login.UseVisualStyleBackColor = false;
            this.button_login.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox_rwm
            // 
            this.textBox_rwm.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox_rwm.Cursor = System.Windows.Forms.Cursors.WaitCursor;
            this.textBox_rwm.Font = new System.Drawing.Font("Dubai", 18F, System.Drawing.FontStyle.Bold);
            this.textBox_rwm.ForeColor = System.Drawing.SystemColors.InfoText;
            this.textBox_rwm.Location = new System.Drawing.Point(42, 13);
            this.textBox_rwm.Multiline = true;
            this.textBox_rwm.Name = "textBox_rwm";
            this.textBox_rwm.Size = new System.Drawing.Size(149, 40);
            this.textBox_rwm.TabIndex = 3;
            this.textBox_rwm.Text = "R.W.M Web";
            this.textBox_rwm.UseWaitCursor = true;
            this.textBox_rwm.TextChanged += new System.EventHandler(this.textBox_rwm_TextChanged);
            // 
            // pictureBox1_livro1
            // 
            this.pictureBox1_livro1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1_livro1.Image")));
            this.pictureBox1_livro1.Location = new System.Drawing.Point(51, 112);
            this.pictureBox1_livro1.Name = "pictureBox1_livro1";
            this.pictureBox1_livro1.Size = new System.Drawing.Size(125, 181);
            this.pictureBox1_livro1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1_livro1.TabIndex = 4;
            this.pictureBox1_livro1.TabStop = false;
            this.pictureBox1_livro1.Click += new System.EventHandler(this.pictureBox1_livro1_Click);
            // 
            // pictureBox3_livro2
            // 
            this.pictureBox3_livro2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3_livro2.Image")));
            this.pictureBox3_livro2.Location = new System.Drawing.Point(260, 112);
            this.pictureBox3_livro2.Name = "pictureBox3_livro2";
            this.pictureBox3_livro2.Size = new System.Drawing.Size(123, 181);
            this.pictureBox3_livro2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3_livro2.TabIndex = 5;
            this.pictureBox3_livro2.TabStop = false;
            this.pictureBox3_livro2.Click += new System.EventHandler(this.pictureBox3_Click_1);
            // 
            // pictureBox4_livro3
            // 
            this.pictureBox4_livro3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4_livro3.Image")));
            this.pictureBox4_livro3.Location = new System.Drawing.Point(153, 181);
            this.pictureBox4_livro3.Name = "pictureBox4_livro3";
            this.pictureBox4_livro3.Size = new System.Drawing.Size(125, 181);
            this.pictureBox4_livro3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4_livro3.TabIndex = 6;
            this.pictureBox4_livro3.TabStop = false;
            this.pictureBox4_livro3.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox4_livro4
            // 
            this.pictureBox4_livro4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4_livro4.Image")));
            this.pictureBox4_livro4.Location = new System.Drawing.Point(403, 429);
            this.pictureBox4_livro4.Name = "pictureBox4_livro4";
            this.pictureBox4_livro4.Size = new System.Drawing.Size(125, 193);
            this.pictureBox4_livro4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4_livro4.TabIndex = 8;
            this.pictureBox4_livro4.TabStop = false;
            // 
            // pictureBox5_livro5
            // 
            this.pictureBox5_livro5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5_livro5.Image")));
            this.pictureBox5_livro5.ImeMode = System.Windows.Forms.ImeMode.On;
            this.pictureBox5_livro5.Location = new System.Drawing.Point(272, 429);
            this.pictureBox5_livro5.Name = "pictureBox5_livro5";
            this.pictureBox5_livro5.Size = new System.Drawing.Size(125, 193);
            this.pictureBox5_livro5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5_livro5.TabIndex = 9;
            this.pictureBox5_livro5.TabStop = false;
            // 
            // pictureBox6_livro6
            // 
            this.pictureBox6_livro6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6_livro6.Image")));
            this.pictureBox6_livro6.ImeMode = System.Windows.Forms.ImeMode.On;
            this.pictureBox6_livro6.Location = new System.Drawing.Point(534, 429);
            this.pictureBox6_livro6.Name = "pictureBox6_livro6";
            this.pictureBox6_livro6.Size = new System.Drawing.Size(125, 193);
            this.pictureBox6_livro6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6_livro6.TabIndex = 10;
            this.pictureBox6_livro6.TabStop = false;
            this.pictureBox6_livro6.Click += new System.EventHandler(this.pictureBox6_livro6_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Location = new System.Drawing.Point(-2, 967);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(861, 140);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click_1);
            // 
            // text_box_rodapeInicial
            // 
            this.text_box_rodapeInicial.BackColor = System.Drawing.Color.White;
            this.text_box_rodapeInicial.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.text_box_rodapeInicial.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_box_rodapeInicial.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.text_box_rodapeInicial.Location = new System.Drawing.Point(339, 1073);
            this.text_box_rodapeInicial.Name = "text_box_rodapeInicial";
            this.text_box_rodapeInicial.ReadOnly = true;
            this.text_box_rodapeInicial.Size = new System.Drawing.Size(112, 15);
            this.text_box_rodapeInicial.TabIndex = 13;
            this.text_box_rodapeInicial.Text = "© 2021 R.W.M Web";
            this.text_box_rodapeInicial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.text_box_rodapeInicial.TextChanged += new System.EventHandler(this.text_box_rodapeInicial_TextChanged);
            // 
            // pictureBox7_livro7
            // 
            this.pictureBox7_livro7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7_livro7.Image")));
            this.pictureBox7_livro7.Location = new System.Drawing.Point(-2, 716);
            this.pictureBox7_livro7.Name = "pictureBox7_livro7";
            this.pictureBox7_livro7.Size = new System.Drawing.Size(174, 257);
            this.pictureBox7_livro7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7_livro7.TabIndex = 14;
            this.pictureBox7_livro7.TabStop = false;
            this.pictureBox7_livro7.Click += new System.EventHandler(this.pictureBox3_Click_2);
            // 
            // pictureBox8_livro8
            // 
            this.pictureBox8_livro8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8_livro8.Image")));
            this.pictureBox8_livro8.ImeMode = System.Windows.Forms.ImeMode.On;
            this.pictureBox8_livro8.Location = new System.Drawing.Point(167, 716);
            this.pictureBox8_livro8.Name = "pictureBox8_livro8";
            this.pictureBox8_livro8.Size = new System.Drawing.Size(178, 257);
            this.pictureBox8_livro8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox8_livro8.TabIndex = 15;
            this.pictureBox8_livro8.TabStop = false;
            this.pictureBox8_livro8.Click += new System.EventHandler(this.pictureBox8_livro8_Click);
            // 
            // pictureBox9_livro9
            // 
            this.pictureBox9_livro9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9_livro9.Image")));
            this.pictureBox9_livro9.ImeMode = System.Windows.Forms.ImeMode.On;
            this.pictureBox9_livro9.Location = new System.Drawing.Point(339, 716);
            this.pictureBox9_livro9.Name = "pictureBox9_livro9";
            this.pictureBox9_livro9.Size = new System.Drawing.Size(181, 257);
            this.pictureBox9_livro9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox9_livro9.TabIndex = 16;
            this.pictureBox9_livro9.TabStop = false;
            this.pictureBox9_livro9.Click += new System.EventHandler(this.pictureBox9_livro9_Click);
            // 
            // pictureBox10_livro10
            // 
            this.pictureBox10_livro10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10_livro10.Image")));
            this.pictureBox10_livro10.ImeMode = System.Windows.Forms.ImeMode.On;
            this.pictureBox10_livro10.Location = new System.Drawing.Point(517, 716);
            this.pictureBox10_livro10.Name = "pictureBox10_livro10";
            this.pictureBox10_livro10.Size = new System.Drawing.Size(186, 257);
            this.pictureBox10_livro10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox10_livro10.TabIndex = 17;
            this.pictureBox10_livro10.TabStop = false;
            this.pictureBox10_livro10.Click += new System.EventHandler(this.pictureBox6_Click);
            // 
            // pictureBox11_livro11
            // 
            this.pictureBox11_livro11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11_livro11.Image")));
            this.pictureBox11_livro11.ImeMode = System.Windows.Forms.ImeMode.On;
            this.pictureBox11_livro11.Location = new System.Drawing.Point(691, 716);
            this.pictureBox11_livro11.Name = "pictureBox11_livro11";
            this.pictureBox11_livro11.Size = new System.Drawing.Size(168, 257);
            this.pictureBox11_livro11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox11_livro11.TabIndex = 18;
            this.pictureBox11_livro11.TabStop = false;
            this.pictureBox11_livro11.Click += new System.EventHandler(this.pictureBox11_livro11_Click);
            // 
            // textBox1_telaInicial
            // 
            this.textBox1_telaInicial.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBox1_telaInicial.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.textBox1_telaInicial.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1_telaInicial.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold);
            this.textBox1_telaInicial.ForeColor = System.Drawing.Color.White;
            this.textBox1_telaInicial.Location = new System.Drawing.Point(489, 143);
            this.textBox1_telaInicial.Multiline = true;
            this.textBox1_telaInicial.Name = "textBox1_telaInicial";
            this.textBox1_telaInicial.ReadOnly = true;
            this.textBox1_telaInicial.Size = new System.Drawing.Size(334, 70);
            this.textBox1_telaInicial.TabIndex = 19;
            this.textBox1_telaInicial.Text = "Conhecimento é a base para o sucesso!";
            this.textBox1_telaInicial.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1_telaInicial.TextChanged += new System.EventHandler(this.textBox1_TextChanged_2);
            // 
            // textBox1
            // 
            this.textBox1.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Calibri", 24F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.ForeColor = System.Drawing.Color.White;
            this.textBox1.Location = new System.Drawing.Point(82, 429);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(184, 193);
            this.textBox1.TabIndex = 20;
            this.textBox1.Text = "TEMOS LIVROS DE VÁRIAS CATEGORIAS ->>>>>>";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_3);
            // 
            // pictureBox12_livro12
            // 
            this.pictureBox12_livro12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12_livro12.Image")));
            this.pictureBox12_livro12.Location = new System.Drawing.Point(665, 429);
            this.pictureBox12_livro12.Name = "pictureBox12_livro12";
            this.pictureBox12_livro12.Size = new System.Drawing.Size(121, 193);
            this.pictureBox12_livro12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox12_livro12.TabIndex = 21;
            this.pictureBox12_livro12.TabStop = false;
            // 
            // pictureBox13_background_barra_inicial
            // 
            this.pictureBox13_background_barra_inicial.BackColor = System.Drawing.Color.BlueViolet;
            this.pictureBox13_background_barra_inicial.Location = new System.Drawing.Point(260, 429);
            this.pictureBox13_background_barra_inicial.Name = "pictureBox13_background_barra_inicial";
            this.pictureBox13_background_barra_inicial.Size = new System.Drawing.Size(607, 193);
            this.pictureBox13_background_barra_inicial.TabIndex = 22;
            this.pictureBox13_background_barra_inicial.TabStop = false;
            this.pictureBox13_background_barra_inicial.Click += new System.EventHandler(this.pictureBox3_Click_3);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 14F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(944, 715);
            this.Controls.Add(this.button_cadastro);
            this.Controls.Add(this.pictureBox12_livro12);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox1_telaInicial);
            this.Controls.Add(this.pictureBox11_livro11);
            this.Controls.Add(this.pictureBox10_livro10);
            this.Controls.Add(this.pictureBox9_livro9);
            this.Controls.Add(this.pictureBox8_livro8);
            this.Controls.Add(this.pictureBox7_livro7);
            this.Controls.Add(this.text_box_rodapeInicial);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox4_livro4);
            this.Controls.Add(this.pictureBox6_livro6);
            this.Controls.Add(this.pictureBox5_livro5);
            this.Controls.Add(this.pictureBox4_livro3);
            this.Controls.Add(this.pictureBox3_livro2);
            this.Controls.Add(this.pictureBox1_livro1);
            this.Controls.Add(this.textBox_rwm);
            this.Controls.Add(this.button_login);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox13_background_barra_inicial);
            this.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold);
            this.ForeColor = System.Drawing.Color.Transparent;
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1_livro1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3_livro2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_livro3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4_livro4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5_livro5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6_livro6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7_livro7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8_livro8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9_livro9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10_livro10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11_livro11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12_livro12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13_background_barra_inicial)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

    #endregion

    private System.Windows.Forms.PictureBox pictureBox1;
    private System.Windows.Forms.Button button_cadastro;
    private System.Windows.Forms.Button button_login;
    private System.Windows.Forms.TextBox textBox_rwm;
    private System.Windows.Forms.PictureBox pictureBox1_livro1;
    private System.Windows.Forms.PictureBox pictureBox3_livro2;
    private System.Windows.Forms.PictureBox pictureBox4_livro3;
    private System.Windows.Forms.PictureBox pictureBox4_livro4;
    private System.Windows.Forms.PictureBox pictureBox5_livro5;
    private System.Windows.Forms.PictureBox pictureBox6_livro6;
    private System.Windows.Forms.PictureBox pictureBox2;
    private System.Windows.Forms.TextBox text_box_rodapeInicial;
    private System.Windows.Forms.PictureBox pictureBox7_livro7;
    private System.Windows.Forms.PictureBox pictureBox8_livro8;
    private System.Windows.Forms.PictureBox pictureBox9_livro9;
    private System.Windows.Forms.PictureBox pictureBox10_livro10;
    private System.Windows.Forms.PictureBox pictureBox11_livro11;
    private System.Windows.Forms.TextBox textBox1_telaInicial;
    private System.Windows.Forms.TextBox textBox1;
    private System.Windows.Forms.PictureBox pictureBox12_livro12;
    private System.Windows.Forms.PictureBox pictureBox13_background_barra_inicial;
  }
}

