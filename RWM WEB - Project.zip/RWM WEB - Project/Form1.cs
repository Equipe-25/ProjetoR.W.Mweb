using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RWM_WEB___Project{
    public partial class Form1 : Form{
        public Form1(){
            InitializeComponent();
        }

    private void Form1_Load(object sender, EventArgs e){

    }

    private void pictureBox1_Click(object sender, EventArgs e){

    }
    private void pictureBox3_Click(object sender, EventArgs e)
    {

    }
    private void pictureBox2_Click(object sender, EventArgs e){

    }

    private void pictureBox3_Click(object sender, EventArgs e){

    }

    private void button_cadastro(object sender, EventArgs e){
      //ligação com o botão de cadastro
    }

    private void button_login(object sender, EventArgs e){
      //ligação com o botão de login
    }

    private void textBox_rwm_TextChanged(object sender, EventArgs e)
    {

    }

    private void pictureBox4_Click(object sender, EventArgs e)
    {

    }

    private void pictureBox3_Click_1(object sender, EventArgs e)
    {

    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {

    }

    private void pictureBox1_livro1_Click(object sender, EventArgs e)
    {

    }

    private void textBox1_TextChanged_1(object sender, EventArgs e)
    {

    }

    private void pictureBox6_livro6_Click(object sender, EventArgs e)
    {

    }

    private void pictureBox2_Click_1(object sender, EventArgs e)
    {

    }

    private void pictureBox6_Click(object sender, EventArgs e)
    {

    }

    private void text_box_rodapeInicial_TextChanged(object sender, EventArgs e)
    {

    }

    private void pictureBox3_Click_2(object sender, EventArgs e)
    {

    }

    private void pictureBox9_livro9_Click(object sender, EventArgs e)
    {

    }

    private void pictureBox11_livro11_Click(object sender, EventArgs e)
    {

    }

    private void pictureBox8_livro8_Click(object sender, EventArgs e)
    {

    }

    private void textBox1_TextChanged_2(object sender, EventArgs e)
    {

    }

    private void textBox1_TextChanged_3(object sender, EventArgs e)
    {

    }

    private void pictureBox3_Click_3(object sender, EventArgs e)
    {

    }
  }
}
